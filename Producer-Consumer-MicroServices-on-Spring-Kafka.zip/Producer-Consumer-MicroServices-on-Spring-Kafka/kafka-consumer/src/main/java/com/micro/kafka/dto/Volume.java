package com.micro.kafka.dto;
public class Volume {
    private long l;
    private long b;
    private long h;
    public void setL(long l){ this.l = l;}
    public void setB(long b){ this.b = b;}
    public void setH(long h){ this.h = h;}
    public long getL(){ return this.l;}
    public long getB(){ return this.b;}
    public long getH(){ return this.h;}
}
